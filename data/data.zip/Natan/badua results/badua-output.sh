echo "Removing files"
rm coverage.ser
rm output.xml
rm *.class
rm max/*.class

echo "Compiling MDC class"
javac -g max/Max.java

echo "Compiling Test Class"
javac -cp /Users/marcoschaim/.m2/repository/org/hamcrest/hamcrest-core/1.3/hamcrest-core-1.3.jar:/Users/marcoschaim/.m2/repository/junit/junit/4.12/junit-4.12.jar:. TestMax.java

echo "Running classes"
java -cp /Users/marcoschaim/.m2/repository/org/hamcrest/hamcrest-core/1.3/hamcrest-core-1.3.jar:/Users/marcoschaim/.m2/repository/junit/junit/4.12/junit-4.12.jar:.  org.junit.runner.JUnitCore TestMax
java -cp /Users/marcoschaim/.m2/repository/org/hamcrest/hamcrest-core/1.3/hamcrest-core-1.3.jar:/Users/marcoschaim/.m2/repository/junit/junit/4.12/junit-4.12.jar:. -javaagent:/Users/marcoschaim/experimentos/badua/lib/ba-dua-agent-rt-0.4.0-all.jar org.junit.runner.JUnitCore TestMax

echo "Generating report"
java -jar  /Users/marcoschaim/experimentos/badua/lib/ba-dua-cli-0.4.0-all.jar  report -classes max -input coverage.ser  -xml output.xml
