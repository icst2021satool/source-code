import static org.junit.Assert.assertEquals;
import org.junit.*;

import max.Max;

public class TestMax {
	
	@Test
	public void TestCase1()
	{
		Max x = new Max();
		int[] arr  = {50,9,12,4,6,-1,1,10,25};
		assertEquals(50, x.max(arr, arr.length));
	}
	
	@Test
	public void TestCase2()
	{
		Max x = new Max();
		int[] arr  = {50,9,12,4,6,-1,1,10,250};
		assertEquals(250, x.max(arr, arr.length));
	}
	

}
