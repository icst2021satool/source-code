package max;

public class Max {
	
	public int max (int[] array, int length)
	{
		int i = 0;
		int max = array[i++]; //i++
		while (i < length)
		{
			if (array[i] > max)
				max = array[i];
			i++;
		}
		return max;
	}

}
